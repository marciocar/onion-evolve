# Fixture anonimizada: corpus de um adotante hub antes da migração ao contrato KG-SSOT v4

- Estado: o corpus de um adotante real (papel hub) no commit anterior à migração v4.
- `docs/graphs/g01..g25.kg.yaml`: os 25 grafos com a estrutura intacta. Os ids são hash estável (`N_<12 hex>`).
  - Ficaram node_type, plane, status, impact, confidence, layer, source_kind, valid_from, verified_at e as arestas inteiras, sem rótulo.
  - O label é `nó <hash>` e a narrative saiu. O verified_against ficou com texto genérico.
  - A provenance que já existia (o grafo de compliance, nascido v4) ficou com a classe do method e a locality.
- O trace é sintético, da mesma classe que o classificador da migração deu ao original.
  - Classes: código `src/mod<n>.<ext>:12` ou `src/dir<n>/`; fonte `docs/fontes/`, `docs/knowledge-base/` ou `docs/dados/`; prosa `docs/prosa/`; reunião `docs/meetings/`; pesquisa `docs/research/`; outro grafo; `https://exemplo.org/<n>`; `drive:<n>`; `conversa 2026-10-09`; `script nunca versionado`; vazio.
  - Os caminhos existem na árvore (arquivos vazios). Os `src/ausente<n>.ts` não existem, de propósito.
- `esperado.csv`: uma linha por nó do universo, ou seja, confirmed ou PROD, não unverifiable e sem provenance: 1.024 nós.
  - Colunas: grafo, id_hash, regra que casou, classe do method, locality e status depois, tirados do commit da migração.
  - **A chave é grafo + id_hash**, porque 19 ids se repetem entre grafos.
  - Contagens: leitura-codigo 489, leitura-fonte 240, testemunho-prosa 130, leitura-web 65, testemunho-web 24, derivado-arestas 23, leitura-drive 21, derivado-pesquisa 14, derivado-grafo 13, testemunho-maestro 2, testemunho-reuniao 1, rebaixado-unverifiable 2.
- `scopes.yaml`: os 15 ids de `verified_scope: mecanismo` e os 3 de `nenhum` (aplicados na v4.12.0), com hash.
- Autoconferência: reclassificar a fixture com o mesmo classificador dá a mesma regra para os 1.022 nós migrados.
